import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";

describe("admin.summarizeReports", () => {
  it("rejects anonymous callers before reading reports or invoking the model", async () => {
    const caller = appRouter.createCaller({ user: null, req: { headers: {}, protocol: "https" } as never, res: {} as never });
    await expect(caller.admin.summarizeReports()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
