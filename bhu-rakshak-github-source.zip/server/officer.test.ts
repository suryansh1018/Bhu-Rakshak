import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";

describe("officer case workflow", () => {
  it("rejects anonymous status changes", async () => {
    const caller = appRouter.createCaller({ user: null, req: { headers: {}, protocol: "https" } as never, res: {} as never });
    await expect(caller.admin.updateReportStatus({ id: 1, status: "reviewing" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
