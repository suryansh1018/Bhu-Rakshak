import { afterEach, describe, expect, it, vi } from "vitest";
import { getLiveCorridors } from "./liveData";

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe("live monitor resilience", () => {
  it("returns safe fallback corridor data when the weather feed is unavailable", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("weather feed offline")));

    const corridors = await getLiveCorridors();

    expect(corridors).toHaveLength(7);
    expect(corridors.every(corridor => corridor.source.includes("unavailable"))).toBe(true);
    expect(corridors.every(corridor => corridor.riskLevel === "low")).toBe(true);
  });
});
