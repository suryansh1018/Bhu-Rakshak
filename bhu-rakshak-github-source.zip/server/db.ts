import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { alertSubscriptions, incidentReports, riskSnapshots, signInEvents, type InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  } else {
    values.lastSignedIn = new Date();
    updateSet.lastSignedIn = values.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function recordSignInEvent(input: { userOpenId: string; userName?: string | null; email?: string | null; role?: "user" | "admin"; loginMethod?: string | null }) {
  const db = await getDb();
  if (!db) return;
  try {
    await db.insert(signInEvents).values({
      userOpenId: input.userOpenId,
      userName: input.userName ?? null,
      email: input.email ?? null,
      role: input.role ?? "user",
      loginMethod: input.loginMethod ?? null,
      signedInAt: new Date(),
    });
  } catch (error) {
    console.warn("[Database] Sign-in audit write skipped:", error);
  }
}

export async function listSignInEvents(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(signInEvents).orderBy(desc(signInEvents.signedInAt)).limit(limit);
}

export async function listIncidentReports(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(incidentReports).orderBy(desc(incidentReports.createdAt)).limit(limit);
}

export async function updateIncidentStatus(id: number, status: "received" | "reviewing" | "resolved") {
  const db = await getDb();
  if (!db) return { id, status, persisted: false };
  await db.update(incidentReports).set({ status, updatedAt: new Date() }).where(eq(incidentReports.id, id));
  return { id, status, persisted: true };
}

export async function getAdminStats() {
  const db = await getDb();
  if (!db) return { reports: 0, signIns: 0, users: 0 };
  const [reports, signIns, userRows] = await Promise.all([
    db.select({ id: incidentReports.id }).from(incidentReports),
    db.select({ id: signInEvents.id }).from(signInEvents),
    db.select({ id: users.id }).from(users),
  ]);
  return { reports: reports.length, signIns: signIns.length, users: userRows.length };
}

export async function createAlertSubscription(input: { phone: string; corridorId: string; channel: "whatsapp" | "sms" }) {
  const db = await getDb();
  if (!db) return { id: 0, ...input, persisted: false };
  const result = await db.insert(alertSubscriptions).values({ ...input, consent: 1 });
  return { id: Number(result[0].insertId), ...input, persisted: true };
}

export async function createIncidentReport(input: { corridorId: string; description: string; latitude?: number; longitude?: number; imageKey?: string; imageUrl?: string }) {
  const db = await getDb();
  if (!db) return { id: 0, ...input, status: "received", persisted: false };
  const result = await db.insert(incidentReports).values({ ...input, status: "received" });
  return { id: Number(result[0].insertId), ...input, status: "received", persisted: true };
}

export async function saveRiskSnapshots(snapshots: Array<{ corridorId: string; rainfall24h: number; rainfall7d: number; riskLevel: "low" | "moderate" | "high"; riskScore: number; factorOfSafety: number; source: string; measuredAt: Date }>) {
  const db = await getDb();
  if (!db || snapshots.length === 0) return;
  try {
    await db.insert(riskSnapshots).values(snapshots);
  } catch (error) {
    console.warn("[Database] Risk snapshot persistence skipped:", error);
  }
}

export async function getLatestRiskSnapshot(corridorId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(riskSnapshots).where(eq(riskSnapshots.corridorId, corridorId)).orderBy(desc(riskSnapshots.measuredAt)).limit(1);
  return result[0];
}
