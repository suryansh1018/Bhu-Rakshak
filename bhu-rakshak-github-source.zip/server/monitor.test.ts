import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("monitor procedures", () => {
  it("normalizes and stores a WhatsApp alert preference", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.monitor.subscribe({ phone: "+91 (98765) 43210", corridorId: "nh10", channel: "whatsapp" });
    expect(result.phone).toBe("+919876543210");
    expect(result.corridorId).toBe("nh10");
    expect(result.channel).toBe("whatsapp");
    expect(result).toHaveProperty("persisted");
  });

  it("accepts a citizen report with GPS coordinates", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.monitor.reportIncident({ corridorId: "sohra", description: "Fresh cracks beside the road near the bend", latitude: 25.2744, longitude: 91.7323 });
    expect(result.corridorId).toBe("sohra");
    expect(result.latitude).toBe(25.2744);
    expect(result.longitude).toBe(91.7323);
    expect(result.status).toBe("received");
  });
});
