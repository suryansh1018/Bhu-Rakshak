import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(async () => ({
    choices: [{ message: { content: "Stay away from the slope and check the live map." } }],
  })),
}));

vi.mock("./liveData", () => ({
  getLiveCorridors: vi.fn(async () => [{
    id: "nh10",
    name: "NH-10",
    state: "Sikkim",
    rainfall24h: 12.4,
    riskLevel: "moderate",
    leadTime: "12–18 hrs",
    source: "test feed",
  }]),
  getImdBulletins: vi.fn(async () => []),
}));

describe("assistant.ask", () => {
  it("returns a safety response using the public assistant procedure", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: { protocol: "https", headers: {} } as never,
      res: {} as never,
    });
    const result = await caller.assistant.ask({ language: "Hindi", messages: [{ role: "user", content: "Is NH-10 safe?" }] });
    expect(result.answer).toContain("Stay away from the slope");
  });

  it("rejects oversized or empty user messages", async () => {
    const caller = appRouter.createCaller({ user: null, req: {} as never, res: {} as never });
    await expect(caller.assistant.ask({ messages: [] })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(caller.assistant.ask({ messages: [{ role: "user", content: "x".repeat(2_001) }] })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
