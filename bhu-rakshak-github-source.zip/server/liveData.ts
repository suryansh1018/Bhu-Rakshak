export type RiskLevel = "low" | "moderate" | "high";

export type CorridorDefinition = {
  id: string;
  name: string;
  state: string;
  latitude: number;
  longitude: number;
  road: string;
  slopeFactor: number;
};

export type CorridorSnapshot = CorridorDefinition & {
  rainfall24h: number;
  rainfall7d: number;
  temperature: number | null;
  humidity: number | null;
  windSpeed: number | null;
  riskLevel: RiskLevel;
  riskScore: number;
  factorOfSafety: number;
  leadTime: string;
  source: string;
  measuredAt: string;
};

export type Bulletin = {
  id: string;
  title: string;
  summary: string;
  severity: "info" | "watch" | "urgent";
  source: string;
  publishedAt: string;
  link?: string;
};

export const CORRIDORS: CorridorDefinition[] = [
  { id: "nh10", name: "NH-10 · Sevoke – Rongpo", state: "Sikkim", latitude: 27.17, longitude: 88.56, road: "Sevoke–Rongpo corridor", slopeFactor: 1.15 },
  { id: "sohra", name: "Sohra – Shella Escarpment", state: "Meghalaya", latitude: 25.27, longitude: 91.73, road: "Sohra–Shella road", slopeFactor: 1.3 },
  { id: "nh13", name: "NH-13 · Bhalukpong – Tawang", state: "Arunachal Pradesh", latitude: 27.58, longitude: 91.87, road: "Bhalukpong–Tawang highway", slopeFactor: 1.05 },
  { id: "nh29", name: "NH-29 · Kohima – Dimapur", state: "Nagaland", latitude: 25.67, longitude: 94.11, road: "Kohima–Dimapur slipway", slopeFactor: 1.1 },
  { id: "nh37", name: "NH-37 · Tupul – Noney", state: "Manipur", latitude: 24.78, longitude: 93.67, road: "Tupul–Noney hill section", slopeFactor: 1.22 },
  { id: "champhai", name: "Champhai Fault Axis", state: "Mizoram", latitude: 23.46, longitude: 93.33, road: "Champhai frontier road", slopeFactor: 1.18 },
  { id: "lumding", name: "Lumding – Badarpur Spur", state: "Assam", latitude: 25.44, longitude: 93.18, road: "Dima Hasao rail corridor", slopeFactor: 1.12 },
];

function round(value: number, decimals = 1) {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

async function fetchOpenMeteo(corridor: CorridorDefinition): Promise<CorridorSnapshot> {
  const params = new URLSearchParams({
    latitude: String(corridor.latitude),
    longitude: String(corridor.longitude),
    hourly: "precipitation",
    daily: "precipitation_sum",
    current: "temperature_2m,relative_humidity_2m,wind_speed_10m",
    past_days: "7",
    forecast_days: "1",
    timezone: "UTC",
  });
  const response = await fetch(`https://api.open-meteo.com/v1/forecast?${params.toString()}`, {
    headers: { Accept: "application/json", "User-Agent": "Bhu-Rakshak/1.0" },
    signal: AbortSignal.timeout(8_000),
  });
  if (!response.ok) throw new Error(`Open-Meteo ${response.status}`);
  const data = (await response.json()) as {
    hourly?: { precipitation?: number[] };
    daily?: { precipitation_sum?: number[] };
    current?: { temperature_2m?: number; relative_humidity_2m?: number; wind_speed_10m?: number };
  };
  const hourly = data.hourly?.precipitation ?? [];
  const last24 = hourly.slice(-24).reduce((sum, value) => sum + (Number(value) || 0), 0);
  const daily = data.daily?.precipitation_sum ?? [];
  const last7 = daily.slice(0, 7).reduce((sum, value) => sum + (Number(value) || 0), 0);
  const riskScore = Math.max(4, Math.min(98, Math.round(last24 * 0.45 + last7 * 0.055 + corridor.slopeFactor * 9)));
  const riskLevel: RiskLevel = riskScore >= 70 ? "high" : riskScore >= 38 ? "moderate" : "low";
  const factorOfSafety = round(Math.max(0.82, 1.72 - riskScore / 100), 2);
  const leadTime = riskLevel === "high" ? "< 6 hrs" : riskLevel === "moderate" ? "12–18 hrs" : "24+ hrs";
  return {
    ...corridor,
    rainfall24h: round(last24),
    rainfall7d: round(last7),
    temperature: data.current?.temperature_2m == null ? null : round(data.current.temperature_2m),
    humidity: data.current?.relative_humidity_2m == null ? null : Math.round(data.current.relative_humidity_2m),
    windSpeed: data.current?.wind_speed_10m == null ? null : round(data.current.wind_speed_10m),
    riskLevel,
    riskScore,
    factorOfSafety,
    leadTime,
    source: "Open-Meteo rainfall + Bhu-Rakshak corridor model",
    measuredAt: new Date().toISOString(),
  };
}

export async function getLiveCorridors() {
  const results = await Promise.allSettled(CORRIDORS.map(fetchOpenMeteo));
  return results.map((result, index) => {
    if (result.status === "fulfilled") return result.value;
    const corridor = CORRIDORS[index];
    return {
      ...corridor,
      rainfall24h: 0,
      rainfall7d: 0,
      temperature: null,
      humidity: null,
      windSpeed: null,
      riskLevel: "low" as const,
      riskScore: 0,
      factorOfSafety: 1.72,
      leadTime: "24+ hrs",
      source: "Live feed unavailable · awaiting refresh",
      measuredAt: new Date().toISOString(),
    };
  });
}

export async function getImdBulletins(): Promise<Bulletin[]> {
  try {
    const response = await fetch("https://cap-sources.s3.amazonaws.com/in-imd-en/rss.xml", {
      headers: { Accept: "application/rss+xml, application/xml, text/xml", "User-Agent": "Bhu-Rakshak/1.0" },
      signal: AbortSignal.timeout(8_000),
    });
    if (!response.ok) throw new Error(`IMD CAP ${response.status}`);
    const xml = await response.text();
    const items = Array.from(xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)).slice(0, 4);
    const strip = (value: string) => value.replace(/<!\[CDATA\[|\]\]>/g, "").replace(/<[^>]*>/g, "").trim();
    const parsed = items.map((match, index) => {
      const body = match[1] ?? "";
      const read = (tag: string) => strip(body.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"))?.[1] ?? "");
      const title = read("title") || "IMD weather bulletin";
      const description = read("description") || "Official weather and warning information is available from IMD.";
      const link = read("link");
      const pubDate = read("pubDate");
      return { id: `imd-${index}-${pubDate}`, title, summary: description.slice(0, 180), severity: /red|heavy|severe|cyclone|landslide/i.test(`${title} ${description}`) ? "urgent" : "watch", source: "India Meteorological Department", publishedAt: pubDate || new Date().toISOString(), link } as Bulletin;
    });
    if (parsed.length) return parsed;
  } catch (error) {
    console.warn("[Bhu-Rakshak] IMD bulletin fetch failed", error);
  }
  return [{ id: "fallback-imd", title: "Live IMD bulletin feed is refreshing", summary: "Rainfall data remains available while the official warning feed reconnects.", severity: "info", source: "Bhu-Rakshak monitor", publishedAt: new Date().toISOString() }];
}
