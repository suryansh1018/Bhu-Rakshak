import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { ADMIN_SESSION_COOKIE } from "./adminAuth";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): { ctx: TrpcContext; cookies: string[] } {
  const cookies: string[] = [];
  return {
    cookies,
    ctx: {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { cookie: (name: string) => cookies.push(name) } as unknown as TrpcContext["res"],
    },
  };
}

function createOAuthAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "oauth-admin",
      name: "OAuth Admin",
      email: "admin@example.com",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("admin password endpoint", () => {
  it("accepts the configured admin password and issues an admin session", async () => {
    const password = process.env.ADMIN_DASHBOARD_PASSWORD;
    expect(password).toBeTruthy();
    const { ctx, cookies } = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.adminLogin({ password: password as string });
    expect(result).toEqual({ success: true, role: "admin" });
    expect(cookies).toContain(ADMIN_SESSION_COOKIE);
  });

  it("rejects an incorrect password", async () => {
    const caller = appRouter.createCaller(createPublicContext().ctx);
    await expect(caller.auth.adminLogin({ password: "definitely-not-the-admin-password" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("protects admin dashboard procedures from anonymous callers", async () => {
    const caller = appRouter.createCaller(createPublicContext().ctx);
    await expect(caller.admin.me()).resolves.toEqual({ authenticated: false, role: null });
    await expect(caller.admin.stats()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("requires the dedicated password session even for OAuth admins", async () => {
    const caller = appRouter.createCaller(createOAuthAdminContext());
    await expect(caller.admin.me()).resolves.toEqual({ authenticated: false, role: null });
    await expect(caller.admin.stats()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
