import { useEffect, useRef, useState } from "react";
import { AIChatBox, type Message } from "@/components/AIChatBox";
import { trpc } from "@/lib/trpc";
import { Languages, MessageCircle, Mic, MicOff, Sparkles, Volume2, VolumeX, X } from "lucide-react";
import { toast } from "sonner";

type AssistantLanguage = "English" | "Hindi" | "Bengali" | "Assamese";
type RecognitionEvent = { results: ArrayLike<ArrayLike<{ transcript: string }>> };
type Recognition = { lang: string; continuous: boolean; interimResults: boolean; start: () => void; stop: () => void; onresult: ((event: RecognitionEvent) => void) | null; onend: (() => void) | null; onerror: (() => void) | null };
type RecognitionConstructor = new () => Recognition;

declare global { interface Window { SpeechRecognition?: RecognitionConstructor; webkitSpeechRecognition?: RecognitionConstructor } }

const welcome: Message = { role: "assistant", content: "Namaste! I’m **Bhu-Rakshak Saathi**. Ask me about route safety, rainfall, what to do near a slope, or how to report an incident. For immediate danger, move away from the slope and call **112**." };
const languageLocale: Record<AssistantLanguage, string> = { English: "en-IN", Hindi: "hi-IN", Bengali: "bn-IN", Assamese: "as-IN" };

export default function CitizenAssistant() {
  const [open, setOpen] = useState(false);
  const [language, setLanguage] = useState<AssistantLanguage>("English");
  const [spokenReplies, setSpokenReplies] = useState(false);
  const [listening, setListening] = useState(false);
  const [messages, setMessages] = useState<Message[]>([welcome]);
  const recognitionRef = useRef<Recognition | null>(null);
  const assistantMutation = trpc.assistant.ask.useMutation({
    onSuccess: ({ answer }) => {
      setMessages(current => [...current, { role: "assistant", content: answer }]);
      if (spokenReplies && "speechSynthesis" in window) { window.speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(answer.replace(/[*#`]/g, "")); utterance.lang = languageLocale[language]; window.speechSynthesis.speak(utterance); }
    },
    onError: error => { toast.error("Saathi is temporarily unavailable", { description: error.message }); setMessages(current => [...current, { role: "assistant", content: "I’m having trouble connecting right now. Please check the live map, try again shortly, or call 112 for immediate danger." }]); },
  });

  useEffect(() => () => { recognitionRef.current?.stop(); window.speechSynthesis?.cancel(); }, []);

  const sendMessage = (content: string) => {
    const next = [...messages, { role: "user" as const, content }];
    setMessages(next);
    assistantMutation.mutate({ language, messages: next.filter((message): message is Message & { role: "user" | "assistant" } => message.role !== "system").map(message => ({ role: message.role, content: message.content })) });
  };

  const toggleListening = () => {
    if (listening) { recognitionRef.current?.stop(); setListening(false); return; }
    const Recognition = window.SpeechRecognition ?? window.webkitSpeechRecognition;
    if (!Recognition) { toast.error("Voice input is not supported in this browser", { description: "Try Chrome or Edge, or type your question instead." }); return; }
    const recognition = new Recognition();
    recognition.lang = languageLocale[language]; recognition.continuous = false; recognition.interimResults = false;
    recognition.onresult = event => { const transcript = event.results[0]?.[0]?.transcript?.trim(); if (transcript) sendMessage(transcript); };
    recognition.onend = () => setListening(false); recognition.onerror = () => { setListening(false); toast.error("I couldn't hear that", { description: "Please try again in a quieter place." }); };
    recognitionRef.current = recognition; setListening(true); recognition.start();
  };

  return <>
    {open && <div className="assistant-panel motion-pop-in fixed bottom-24 right-4 z-50 w-[min(440px,calc(100vw-2rem))] overflow-hidden rounded-[28px] border border-[#d9e5da] bg-[#fbfcf8] shadow-[0_24px_80px_rgba(24,53,38,0.24)] sm:right-6"><div className="bg-[#17392b] px-5 py-4 text-white"><div className="flex items-center justify-between"><div className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-2xl bg-[#f4c993] text-[#49311f] shadow-sm"><Sparkles size={17} /></div><div><p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#bcd7c0]">Bhu-Rakshak Saathi</p><h2 className="font-display text-lg font-semibold">Ask a safety question</h2></div></div><button onClick={() => setOpen(false)} className="rounded-full p-2 text-[#cfe3d1] transition hover:bg-white/10" aria-label="Close assistant"><X size={18} /></button></div><div className="mt-4 flex flex-wrap items-center gap-2"><label className="flex items-center gap-2 rounded-full bg-white/10 px-3 py-2 text-[11px] font-bold"><Languages size={14} /><span className="sr-only">Assistant language</span><select value={language} onChange={event => setLanguage(event.target.value as AssistantLanguage)} className="bg-transparent text-white outline-none"><option className="text-[#17392b]">English</option><option className="text-[#17392b]">Hindi</option><option className="text-[#17392b]">Bengali</option><option className="text-[#17392b]">Assamese</option></select></label><button onClick={toggleListening} className={`flex items-center gap-2 rounded-full px-3 py-2 text-[11px] font-bold transition ${listening ? "bg-[#f4c993] text-[#49311f]" : "bg-white/10 text-white hover:bg-white/15"}`} aria-pressed={listening}>{listening ? <MicOff size={14} /> : <Mic size={14} />}{listening ? "Listening…" : "Speak"}</button><button onClick={() => setSpokenReplies(value => !value)} className="flex items-center gap-2 rounded-full bg-white/10 px-3 py-2 text-[11px] font-bold text-white transition hover:bg-white/15" aria-pressed={spokenReplies}>{spokenReplies ? <Volume2 size={14} /> : <VolumeX size={14} />}{spokenReplies ? "Voice on" : "Read aloud"}</button></div></div><AIChatBox messages={messages} onSendMessage={sendMessage} isLoading={assistantMutation.isPending} height={430} className="rounded-none border-0 shadow-none" placeholder={`Ask in ${language}…`} emptyStateMessage="Ask Saathi about staying safe" suggestedPrompts={["Is it safe to travel today?", "What should I do if I see cracks?", "How do I report an incident?"]} /></div>}
    <button onClick={() => setOpen(value => !value)} className="assistant-fab group fixed bottom-5 right-4 z-50 flex items-center gap-2 rounded-full bg-[#d37e4c] px-4 py-3.5 text-sm font-bold text-white shadow-[0_12px_28px_rgba(211,126,76,0.34)] transition hover:-translate-y-1 hover:bg-[#bf6d3d] sm:right-6" aria-expanded={open} aria-label={open ? "Close safety assistant" : "Open safety assistant"}>{open ? <X size={18} /> : <MessageCircle size={18} />}<span className="hidden sm:inline">{open ? "Close Saathi" : "Ask Saathi"}</span><span className="assistant-orbit" /></button>
  </>;
}
