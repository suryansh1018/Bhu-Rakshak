CREATE TABLE `alertSubscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phone` varchar(32) NOT NULL,
	`corridorId` varchar(32) NOT NULL,
	`channel` enum('whatsapp','sms') NOT NULL DEFAULT 'whatsapp',
	`consent` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `alertSubscriptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incidentReports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`corridorId` varchar(32) NOT NULL,
	`description` longtext NOT NULL,
	`latitude` double,
	`longitude` double,
	`imageKey` varchar(512),
	`imageUrl` varchar(768),
	`status` enum('received','reviewing','resolved') NOT NULL DEFAULT 'received',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `incidentReports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `riskSnapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`corridorId` varchar(32) NOT NULL,
	`rainfall24h` double NOT NULL,
	`rainfall7d` double NOT NULL,
	`riskLevel` enum('low','moderate','high') NOT NULL,
	`riskScore` double NOT NULL,
	`factorOfSafety` double NOT NULL,
	`source` varchar(128) NOT NULL,
	`measuredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `riskSnapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
