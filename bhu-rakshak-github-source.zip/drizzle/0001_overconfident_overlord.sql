CREATE TABLE `signInEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`userName` text,
	`email` varchar(320),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`loginMethod` varchar(64),
	`signedInAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `signInEvents_id` PRIMARY KEY(`id`)
);
